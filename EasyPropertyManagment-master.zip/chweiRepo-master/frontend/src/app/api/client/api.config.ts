
export namespace APIConfig {
  export const BASE_API_PATH = 'http://localhost:3000';
}
